f2n <- function(.){  as.numeric(as.character(.)) }
